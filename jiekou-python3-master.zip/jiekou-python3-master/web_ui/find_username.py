# -*- coding: utf-8 -*-
from lib2to3.pgen2 import driver
from selenium import webdriver
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import pyautogui as page
import random

browser = webdriver.Chrome()
browser.get("http://stock-test.cciamc.com/admin")
time.sleep(5)
username = browser.find_element(By.XPATH, '/html/body/div/div[2]/form/div[1]/input')
username.send_keys('xuan')
password = browser.find_element(By.XPATH, '/html/body/div/div[2]/form/div[2]/input')
password.send_keys('123456')
login = browser.find_element(By.XPATH, '/html/body/div/div[2]/form/div[4]/div[2]/button')
login.click()
time.sleep(5)
browser.get("http://stock-test.cciamc.com/admin/recharge")
time.sleep(2)
user = browser.find_elements(By.XPATH, "//*[contains(text(),'autouser66')]")
print(user)
