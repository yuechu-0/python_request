# -*- coding: utf-8 -*-
from lib2to3.pgen2 import driver
from selenium import webdriver
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import pyautogui as page
import random
from collections.abc import Iterable
from Public.log import LOG, logger
import logging


def login(browser):     # 登录
    time.sleep(3)
    try:
        username = browser.find_element(By.XPATH, '/html/body/div/div[2]/form/div[1]/input')
        username.send_keys('xuan')
        password = browser.find_element(By.XPATH, '/html/body/div/div[2]/form/div[2]/input')
        password.send_keys('123456')
        login = browser.find_element(By.XPATH, '/html/body/div/div[2]/form/div[4]/div[2]/button')
        login.click()
        time.sleep(3)
    except Exception as e:
        LOG.info('登录时出错，出错原因:%s' % e)


def chongzhi(browser, order_id):     # 编辑最新一条的充值
    url = 'http://stock-test.cciamc.com/admin/recharge/' + order_id + '/edit'
    browser.get(url)
    time.sleep(3)
    try:
        beizhu = browser.find_element(By.XPATH, '//*[@id="comment"]')
        beizhu.send_keys('这是一条备注')
        time.sleep(2)
        browser.find_element(By.XPATH, '/html/body/div/div/div/section[2]/div/div/div/form/div[1]/div/div/div[5]/div/span').click()
        browser.find_element(By.XPATH, '/html/body/span/span/span[2]/ul/li[2]').click()
        browser.find_element(By.XPATH, '//*[@id="app"]/section[2]/div/div/div/form/div[2]/div[2]/div[1]/button').click()
        print('充值成功。')
    except Exception as e:
        LOG.info('编辑充值记录时出错，出错原因:%s' % e)


@logger('操作后台充值记录')
def get_record(user_name):
    browser = webdriver.Chrome()
    browser.get("http://stock-test.cciamc.com/admin/recharge")
    login(browser)
    time.sleep(2)
    browser.get("http://stock-test.cciamc.com/admin/recharge")
    time.sleep(3)
    try:
        for n in range(1, 20):      # 遍历表单中用户名列
            str_n = '/html/body/div/div/div/section[2]/div/div/div/div[3]/table/tbody/tr[%s]/td' % n
            u_name = browser.find_elements(By.XPATH, str_n)
            # print(type(u_name[1].text))
            # print('用户名是:{}, ID是{}'.format(u_name[5].text, u_name[1].text))
            if u_name[5].text == user_name:     # 如果相等，传入用户名对应的订单ID
                chongzhi(browser, u_name[1].text)
                return {'用户名': user_name, '状态': '充值成功'}
    except Exception as e:
        LOG.info('{}充值出错，出错原因:{}'.format(user_name, e))


if __name__ == '__main__':
    get_record('autouser63')
