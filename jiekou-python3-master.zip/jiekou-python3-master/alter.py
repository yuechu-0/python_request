from configparser import ConfigParser
import sys


def alter_config(u_token=None):
    cfg = ConfigParser()
    cfg.read(r'.\config\user_config.ini')

    def get_name():
        u_name = cfg.get('user_config', 'u_name')
        num = int(u_name.split('r')[1]) + 1
        new_str = 'autouser' + str(num)
        cfg.set('user_config', 'u_name', new_str)
        with open(r'.\config\user_config.ini', 'w', encoding='utf-8') as f:
            cfg.write(f)
        return cfg.get('user_config', 'u_name')

    def set_token():
        if u_token:
            cfg.set('user_config', 'token', u_token)
            with open(r'.\config\user_config.ini', 'w', encoding='utf-8') as f:
                cfg.write(f)
            return cfg.get('user_config', 'token')
        else:
            return cfg.get('user_config', 'token')
    return get_name(), set_token()


def get_config():
    cfg = ConfigParser()
    cfg.read(r'.\config\user_config.ini')
    u_name = cfg.get('user_config', 'u_name')
    u_token = cfg.get('user_config', 'token')

    def get_name():
        return u_name

    def get_token():
        return u_token
    return get_name(), get_token()


# def alter(file, old_str, new_str):
#     file_data = ""
#     with open(file, 'r', encoding='utf-8') as f:
#         for line in f:
#             if old_str in line:
#                 line = line.replace(old_str, new_str)
#             file_data += line
#     with open(file, 'w', encoding='utf-8') as f:
#         f.write(file_data)
#         f.close()
#     return new_str
#
#
# def u_name_add():
#     num = int(u_name.split('r')[1]) + 1
#     new_str = 'autouser' + str(num)
#     file_data = ""
#     with open(r'.\config\config_T.py', 'r', encoding='utf-8') as f:
#         for line in f:
#             if u_name in line:
#                 line = line.replace(u_name, new_str)
#             file_data += line
#     with open(r'.\config\config_T.py', 'w', encoding='utf-8') as f:
#         f.write(file_data)
#         f.close()


if __name__ == '__main__':
    # print(alter(r'.\config\config_T.py', token, '777777'))
    # print(config.config_T.token)
    # u_name_add()
    # print(u_name)
    # a = alter_config()
    # print(type(a))
    # print(a[0], a[1])
    a, b = get_config()
    print(type(a), type(b))
    print(a, b)
