# encoding: utf-8
import base64
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from Public.pyreport_excel import create
import os, threading, datetime
from testCase.case import testinterface
from Public.emmail import sendemali
from Public.get_excel import datacel
from Public.create_report import save_result


def start():
    starttime = datetime.datetime.now()
    m = datetime.datetime.now().strftime("%Y%m%d")
    basdir = os.path.abspath(os.path.dirname(__file__))
    path = os.getcwd() + '//test_case_data//case.xlsx'
    listid, listkey, listconeent, listurl, listfangshi, listqiwang, listname = datacel(path)
    listrelust, list_fail, list_pass, list_json,list_weizhi ,listone= testinterface()
    filepath = os.path.join(basdir + '\\test_Report\\%s-result.xls' % m)
    if os.path.exists(filepath) is False:
        os.system(r'touch %s' % filepath)
    save_result(starttime, len(listrelust), list_pass, list_fail)
    create(filename=filepath, list_fail=list_fail, list_pass=list_pass, list_json=list_json, listurls=listurl,
           listkeys=listkey, listconeents=listconeent, listfangshis=listfangshi, listqiwangs=listqiwang,
           listids=listid, listrelust=listrelust, listnames=listname)
# class SendEmail(object):
#     def __init__(self, username, passwd, recv, title, content,
#                  file=None, ssl=False, email_host='smtp.gmail.com', port=465, ssl_port=587):
#         self.username = username
#         self.passwd = passwd
#         # 收件人，多个收件人时需要传list
#         self.recv = recv
#         # 标题
#         self.title = title
#         # 正文
#         self.content = content
#         # 附件路径
#         self.file = file
#         # smtp服务器地址
#         self.email_host = email_host
#         # 普通端口
#         self.port = port
#         # 是否安全连接
#         self.ssl = ssl
#         # 安全链接端口
#         self.ssl_port = ssl_port
#
#     def send_email(self):
#         msg = MIMEMultipart()
#         # 发送内容的对象
#         if self.file:   # 处理附件的
#             file_name = os.path.split(self.file)[-1]    # 只取文件名，不取路径
#             try:
#                 f = open(self.file, 'wb').read()
#             except Exception as e:
#                 raise Exception("附件打不开！")
#             else:
#                 att = MIMEText(f, 'base64', 'utf-8')
#                 att['Content-Type'] = 'application/octet-srteam'
#                 new_file_name = '=?utf-8?b?' + base64.b64encode(file_name.encode()).decode() + '?='
#                 att["Content-Disposition"] = 'attachment; filename="%s"' % new_file_name
#                 msg.attach(att)
#         msg.attach(MIMEText(self.content))      # 邮件正文内容
#         msg['Subject'] = self.title     # 邮件主题
#         msg['From'] = self.username     # 发送者账号
#         msg['To'] = ','.join(self.recv)     # 接收者账号
#         if self.ssl:
#             self.smtp = smtplib.SMTP(self.email_host, port=self.ssl_port)
#         else:
#             self.smtp = smtplib.SMTP(self.email_host, port=self.port)
#         # 发送邮件服务器对象
#         self.smtp.set_debuglevel(1)
#         self.smtp.starttls()
#         self.smtp.login(self.username, self.passwd)
#         try:
#             self.smtp.sendmail(self.username, self.recv, msg.as_string())
#             pass
#         except Exception as e:
#             print('出错了。', e)
#         else:
#             print('发送成功！')
#         self.smtp.quit()


def teThread():
    st = datetime.datetime.now()
    m = threading.Thread(target=start, args=())
    m.run()
    end = datetime.datetime.now()


if __name__ == '__main__':
    teThread()
