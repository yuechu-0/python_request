# -*- coding: utf-8 -*-
# @Time    : 2017/6/4 20:36
# @Author  : lileilei
# @Site    : 
# @File    : testFengzhuang.py
from Public.test_requests import requ

reques = requ()


class TestApi(object):
    def __init__(self, url, key, connent, fangshi):
        self.url = url
        self.key = key
        self.connent = connent
        self.fangshi = fangshi

    def testapi(self):
        if self.fangshi == 'POST':
            if self.key:
                self.parem = {'key': self.key, 'info': self.connent}
            else:
                self.parem = self.connent
            self.response = reques.post(url=self.url, params=self.parem)
            # print(self.parem)
        elif self.fangshi == "GET":
            if self.key == "":
                self.parem = {self.connent}
            else:
                self.parem = {'key': self.key, 'info': self.connent}
            self.response = reques.get(url=self.url, params=self.parem)
        else:
            return '请输入请求方式！'
        return self.response

    def getJson(self):
        json_data = self.testapi()
        return json_data
