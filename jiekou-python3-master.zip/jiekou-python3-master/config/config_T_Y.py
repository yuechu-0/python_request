# Dingtalk_access_token = ""  # 钉钉配置
# TestPlanUrl = 'http://www.tuling123.com'  # 基础url
TestPlanUrl = 'http://stock-test.cciamc.com/'
Config_Try_Num = 3  # 失败重试
