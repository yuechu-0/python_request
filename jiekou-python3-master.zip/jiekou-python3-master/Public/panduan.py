# -*- coding: utf-8 -*-
# @Date    : 2017-08-02 21:54:08
# @Author  : lileilei
from Public.fengzhuang_dict import res
from Public.log import LOG, logger


@logger('断言测试结果')
def assert_in(asserqiwang, fanhuijson):
    if len(asserqiwang.split('=')) > 1:
        data = asserqiwang.split('&')
        result = dict([(item.split('=')) for item in data])
        value1 = ([(str(res(fanhuijson, key))) for key in result.keys()])
        value2 = ([(str(value)) for value in result.values()])
        # print(v1 == v2)
        # print('v1的类型 %s 值 %s' % (v1, type(v1)))
        # print('v2的类型 %s 值 %s' % (v2, type(v2)))
        # print(value1)
        # print(value2)
        # print("value1的值：%s ,类型是 %s" % (value1, type(value1)))
        # print("value2的值：%s ,类型是 %s" % (value2, type(value2)))
        value1_s = list_str(value1)
        if value1_s == value2:
            return {'count': 0, "result": 'pass'}
        else:
            return {'count': 1, 'result': 'fail'}
    else:
        LOG.info('填写测试预期值')
        return {"count": 2, 'result': '填写测试预期值'}


@logger('断言测试结果')
def assertre(asserqingwang):
    if len(asserqingwang.split('=')) > 1:
        data = asserqingwang.split('&')
        result = dict([(item.split('=')) for item in data])
        return result
    else:
        LOG.info('填写测试预期值')
        raise {"count": 1, 'result': '填写测试预期值'}


def list_str(lis):  # 从列表中提取字符串
    list_s = []
    if lis:
        for lis_i in lis:
            if lis_i[0:2] == "['":
                l = lis_i[2:-2]
                list_s.append(l)
            else:
                l = lis_i[1:-1]
                list_s.append(l)
    else:
        return '请传入正确的数据（列表）'
    return list_s


if __name__ == '__main__':
    fanhui = {'count': 200, 'msg': '', 'data': {'id': 30, 'username': 'auto001', 'real_name': None, 'nickname': None, 'balance': '503921.00', 'profit': '-96051740.00', 'captcha': None, 'trade_password': '96e79218965eb72c92a549dd5a330112', 'agent_code': '', 'merchant_code': 'admin', 'card_count': 1, 'token': 'a730db4630e33f4d4387544462944e46', 'trade_time': 100, 'account': None, 'mobile': None, 'level_id': 7, 'avatar': '', 'url_img': '', 'level': {'id': 7, 'title': '至尊VIP', 'level': 7, 'money': '700000.00', 'url': 'stock/images/20220107/32cac52f32c22609f1ea43b582658838.png', 'url_img': 'stock/images/20220107/32cac52f32c22609f1ea43b582658838.png', 'created_at': '2021-12-24 18:09:36', 'updated_at': '2022-01-07 15:56:30'}}}
    assert_in('code=200', fanhui)
